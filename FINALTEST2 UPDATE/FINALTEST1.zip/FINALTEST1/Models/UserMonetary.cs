﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FINALTEST1.Models;

namespace FINALTEST1.Models
{
    public class UserMonetary
    {
        public User User { get; set; }
        
        public Monetary Monetary { get; set; }
    }
}
